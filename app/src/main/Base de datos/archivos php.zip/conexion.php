<?php 
echo "OK";

?>