<?php
//Creamos la conexión
require_once('dbConnect.php');

//generamos la consulta
$email= $_GET["EMAIL"];
$clave= generateRandomString();

$sql = "UPDATE USUARIOS_GALERIA SET CLAVE= '$clave' WHERE EMAIL='$email'";

echo $sql;

mysqli_set_charset($conexion, "utf8"); //formato de datos utf8
if (mysqli_query($conexion, $sql)) {
      echo "OK";
} else {
      echo "ERROR";
}

function generateRandomString($length = 4) { 
    return substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length); 
} 
$headers .= "From: Admin Mis Contactos <miscontactos@policianacional.com>\r\n";
mail($email,"Tu clave de MisContactos","Tu clave es ".$clave,$headers);
//desconectamos la base de datos
$close = mysqli_close($conexion)
or die("Ha sucedido un error inexperado en la desconexion de la base de datos");

?>


 
