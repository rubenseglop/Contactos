<?php  
    if($_SERVER['REQUEST_METHOD']=='GET'){ 
        $uuid= $_GET["UUID"];
        $imagen= $_GET['IMAGEN'];
        $archivo=$_GET['ARCHIVO'];

            if (!file_exists($uuid)) {
                mkdir($uuid, 0777, true);
            }          
        $actualurl = $uuid . "/" . $archivo;
        file_put_contents($actualurl,base64_decode($imagen));
    }
?>