<?php

//Creamos la conexión
require_once('dbConnect.php');

$sql = "DELETE FROM USUARIOS ";
mysqli_set_charset($conexion, "utf8"); //formato de datos utf8
if (mysqli_query($conexion, $sql)) {
    $sql = "DELETE FROM GALERIA";
    if (mysqli_query($conexion, $sql)) {
        $sql = "DELETE FROM DOMICILIO ";
        if (mysqli_query($conexion, $sql)) {
            $sql = "DELETE FROM TELEFONO";
            if (mysqli_query($conexion, $sql)) {
                $sql = "DELETE FROM FOTOS";
                if (mysqli_query($conexion, $sql)) {
                    $sql = "DELETE FROM USUARIOS_GALERIA";
                    if (mysqli_query($conexion, $sql)) {
                    $sql = "ALTER TABLE FOTOS AUTO_INCREMENT = 1";
                    if (mysqli_query($conexion, $sql)) {

                        $dirname = "fotosperfiles";
                        $dir_handle = opendir($dirname);
                        //si no es un directorio devuelvo false para avisar de que ha habido un error
                        if (!$dir_handle)
                            return false;
                            //recorro el contenido del directorio fichero a fichero
                        while($file = readdir($dir_handle)) {
                            if ($file != "." && $file != ".." && $file !="perfil.png") {
                                    //si no es un directorio elemino el fichero con unlink()
                                    if (!is_dir($dirname."/".$file))
                                        unlink($dirname."/".$file);  
                            }
                        }
                        closedir($dir_handle);                        
                        echo "New record created successfully";
                    }
                
                }
            }
            }
        }
    }
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
}

//desconectamos la base de datos
$close = mysqli_close($conexion)
or die("Ha sucedido un error inexperado en la desconexion de la base de datos");

?>