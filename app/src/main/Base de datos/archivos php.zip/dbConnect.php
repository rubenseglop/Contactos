<?php 

 define('HOST','mysql.webcindario.com');
 define('USER','miscontactosrsl');
 define('PASS','probando');
 define('DB','miscontactosrsl');
 
 $conexion = mysqli_connect(HOST,USER,PASS,DB) 
 or die('Ha sucedido un error inexperado en la conexion de la base de datos');


?>